cd ~/pihpsdr
sudo ~/pihpsdr/pihpsdr
