rm -rf /usr/local/lib/libwdsp.so
rm -rf /usr/local/lib/libpsk.so
rm -rf /usr/local/lib/codec2.so
rm -rf /usr/local/lib/codec2.0.5.so
cp libwdsp.so /usr/local/lib
cp libwpsk.so /usr/local/lib
cp libcodec2.0.5.so /usr/local/lib
cd /usr/local/lib; ln -s libcodec2.so.0.5 libcodec2.so
ldconfig
