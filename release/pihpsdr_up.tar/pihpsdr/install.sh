rm -rf /usr/local/lib/libwdsp.so
cp libwdsp.so /usr/local/lib
ldconfig
